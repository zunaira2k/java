package inheritance;

public class Person {
    String name;
    Person(String name){
        this.name = name;
    }
    public String getName() {
    return name;
    }
}
